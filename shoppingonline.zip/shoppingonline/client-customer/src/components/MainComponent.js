import React, { Component } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import Active from './ActiveComponent';
import Home from './HomeComponent';
import Inform from './InformComponent';
import Login from './LoginComponent';
import Menu from './MenuComponent';
import Mycart from './MycartComponent';
import Myorders from './MyordersComponent';
import Myprofile from './MyprofileComponent';
import Product from './ProductComponent';
import ProductDetail from './ProductDetailComponent';
import Signup from './SignupComponent';

class MainComponent extends Component {
  render() {
    return (
      <div className="body-customer">
        <Menu />
        <Inform />
        <Routes>
          <Route path="/" element={<Navigate replace to="/home" />} />
          <Route path="/home" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/active" element={<Active />} />
          <Route path="/myprofile" element={<Myprofile />} />
          <Route path="/mycart" element={<Mycart />} />
          <Route path="/myorders" element={<Myorders />} />
          <Route path="/product/category/:cid" element={<Product />} />
          <Route path="/product/search/:keyword" element={<Product />} />
          <Route path="/product/:id" element={<ProductDetail />} />
        </Routes>
      </div>
    );
  }
}

export default MainComponent;
